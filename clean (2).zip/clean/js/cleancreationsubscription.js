function everythingplan() {
	document.getElementById("plan1").style.display='block';
	document.getElementById("cardplan1").style.display='block';
	document.getElementById("cardplan2").style.display='none';
	document.getElementById("cardplan3").style.display='none';
	document.getElementById("cardplan4").style.display='none';
	document.getElementById("cardplan5").style.display='none';
	document.getElementById("cardplan6").style.display='none';
	document.getElementById("cardplan").style.display='block';
	document.getElementById("plan2").style.display='none';
	document.getElementById("plan3").style.display='none';
	document.getElementById("plan4").style.display='none';
	document.getElementById("plan5").style.display='none';
	document.getElementById("plan6").style.display='none';
	document.getElementById("planprise").innerHTML="$65.00"
}
function lifestyleplan() {
	document.getElementById("plan1").style.display='none';
	document.getElementById("cardplan1").style.display='none';
	document.getElementById("cardplan2").style.display='block';
	document.getElementById("cardplan3").style.display='none';
	document.getElementById("cardplan4").style.display='none';
	document.getElementById("cardplan5").style.display='none';
	document.getElementById("cardplan6").style.display='none';
	document.getElementById("cardplan").style.display='block';
	document.getElementById("plan2").style.display='block';
	document.getElementById("plan3").style.display='none';
	document.getElementById("plan4").style.display='none';
	document.getElementById("plan5").style.display='none';
	document.getElementById("plan6").style.display='none';
	document.getElementById("planprise").innerHTML="$52.50"
}
function cardplan() {
	document.getElementById("plan1").style.display='none';
	document.getElementById("cardplan1").style.display='none';
	document.getElementById("cardplan2").style.display='none';
	document.getElementById("cardplan3").style.display='block';
	document.getElementById("cardplan4").style.display='none';
	document.getElementById("cardplan5").style.display='none';
	document.getElementById("cardplan6").style.display='none';
	document.getElementById("cardplan").style.display='block';
	document.getElementById("plan2").style.display='none';
	document.getElementById("plan3").style.display='block';
	document.getElementById("plan4").style.display='none';
	document.getElementById("plan5").style.display='none';
	document.getElementById("plan6").style.display='none';
	document.getElementById("planprise").innerHTML="$67.50"
}
function pescatarian() {
	document.getElementById("plan1").style.display='none';
	document.getElementById("cardplan1").style.display='none';
	document.getElementById("cardplan2").style.display='none';
	document.getElementById("cardplan3").style.display='none';
	document.getElementById("cardplan4").style.display='block';
	document.getElementById("cardplan5").style.display='none';
	document.getElementById("cardplan6").style.display='none';
	document.getElementById("cardplan").style.display='block';
	document.getElementById("plan2").style.display='none';
	document.getElementById("plan3").style.display='none';
	document.getElementById("plan4").style.display='block';
	document.getElementById("plan5").style.display='none';
	document.getElementById("plan6").style.display='none';
	document.getElementById("planprise").innerHTML="$67.50"
}
function veganplan() {
	document.getElementById("plan1").style.display='none';
	document.getElementById("cardplan1").style.display='none';
	document.getElementById("cardplan2").style.display='none';
	document.getElementById("cardplan3").style.display='none';
	document.getElementById("cardplan4").style.display='none';
	document.getElementById("cardplan5").style.display='block';
	document.getElementById("cardplan6").style.display='none';
	document.getElementById("cardplan").style.display='block';
	document.getElementById("plan2").style.display='none';
	document.getElementById("plan3").style.display='none';
	document.getElementById("plan4").style.display='none';
	document.getElementById("plan5").style.display='block';
	document.getElementById("plan6").style.display='none';
	document.getElementById("planprise").innerHTML="$65.00"
}
function vegplan() {
	document.getElementById("plan1").style.display='none';
	document.getElementById("cardplan1").style.display='none';
	document.getElementById("cardplan2").style.display='none';
	document.getElementById("cardplan3").style.display='none';
	document.getElementById("cardplan4").style.display='none';
	document.getElementById("cardplan5").style.display='none';
	document.getElementById("cardplan6").style.display='block';
	document.getElementById("cardplan").style.display='block';
	document.getElementById("plan2").style.display='none';
	document.getElementById("plan3").style.display='none';
	document.getElementById("plan4").style.display='none';
	document.getElementById("plan5").style.display='none';
	document.getElementById("plan6").style.display='block';
	document.getElementById("planprise").innerHTML="$65.00"
}
function regular(){
	document.getElementById("size").style.display='block';
	document.getElementById("sizetype1").style.display='block';
	document.getElementById("sizetype2").style.display='none';
	document.getElementById("1weekbtn").disabled=false;
	document.getElementById("2weekbtn").disabled=false;
	document.getElementById("4weekbtn").disabled=false;

}
function musclebuilder(){
	document.getElementById("size").style.display='block';
	document.getElementById("sizetype1").style.display='none';
	document.getElementById("sizetype2").style.display='block';
	document.getElementById("1weekbtn").disabled=false;
	document.getElementById("2weekbtn").disabled=false;
	document.getElementById("4weekbtn").disabled=false;
}
function weekbtn1(){
	document.getElementById("renewcycle").style.display='block';
	document.getElementById("renewcycletype1").style.display='block';
	document.getElementById("renewcycletype2").style.display='none';
	document.getElementById("renewcycletype3").style.display='none';
	document.getElementById("weekplanbtn").style.display='block';
}
function weekbtn2(){
	document.getElementById("renewcycle").style.display='block';
	document.getElementById("renewcycletype1").style.display='none';
	document.getElementById("renewcycletype2").style.display='block';
	document.getElementById("renewcycletype3").style.display='none';
	document.getElementById("weekplanbtn").style.display='block';
}
function weekbtn4(){
	document.getElementById("renewcycle").style.display='block';
	document.getElementById("renewcycletype1").style.display='none';
	document.getElementById("renewcycletype2").style.display='none';
	document.getElementById("renewcycletype3").style.display='block';
	document.getElementById("weekplanbtn").style.display='block';
}
function weekplan1(){
    document.getElementById("billplan").style.display='block';
	document.getElementById("billplantype1").style.display='block';
	document.getElementById("billplantype2").style.display='none';
}
function weekplan1(){
    document.getElementById("billplan").style.display='block';
	document.getElementById("billplantype1").style.display='none';
	document.getElementById("billplantype2").style.display='block';
}


function dayperweek(){
    document.getElementById("dperweek").style.display='block';
	document.getElementById("dperweek5").style.display='block';
	document.getElementById("dperweek6").style.display='none';
	document.getElementById("dperweek7").style.display='none';
	document.getElementById("meal1").disabled=false;
	document.getElementById("meal2").disabled=false;
	document.getElementById("meal3").disabled=false;
	document.getElementById("meal4").disabled=false;
}
function dyperweek(){
    document.getElementById("dperweek").style.display='block';
	document.getElementById("dperweek5").style.display='none';
	document.getElementById("dperweek6").style.display='block';
	document.getElementById("dperweek7").style.display='none';
	document.getElementById("meal1").disabled=false;
	document.getElementById("meal2").disabled=false;
	document.getElementById("meal3").disabled=false;
	document.getElementById("meal4").disabled=false;}
function dyaperweek3(){
    document.getElementById("dperweek").style.display='block';
	document.getElementById("dperweek5").style.display='none';
	document.getElementById("dperweek6").style.display='none';
	document.getElementById("dperweek7").style.display='block';
	document.getElementById("meal1").disabled=false;
	document.getElementById("meal2").disabled=false;
	document.getElementById("meal3").disabled=false;
	document.getElementById("meal4").disabled=false;	
}